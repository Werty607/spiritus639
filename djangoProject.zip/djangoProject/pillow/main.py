from PIL import Images

SOURCE_DIR = 'Images/'
p1 = Images.open(SOURCE_DIR + '1.JPG')