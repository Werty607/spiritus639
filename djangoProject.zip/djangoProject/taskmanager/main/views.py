from django.shortcuts import render
from .models import Task


def index(request):
    tasks = Task.objects.all()
    return render(request, 'main/index.html', {'title': 'Главная', 'tasks': tasks})


def about(request):
    return render(request, 'main/about.html')

def supp(request):
    return render(request, 'main/supp.html')

def fory(request):
    return render(request, 'main/fory.html')

def volont(request):
    return render(request, 'main/volont.html')

def our(request):
    return render(request, 'main/our.html')




