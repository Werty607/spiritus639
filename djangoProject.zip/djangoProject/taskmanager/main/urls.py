from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='home'),
    path('fory', views.fory, name = 'fory'),
    path('about-us', views.about, name = 'about'),
    path('supp', views.supp, name = 'supp'),
    path('volont', views.volont, name = 'volont'),
    path('our', views.our, name = 'our'),
]